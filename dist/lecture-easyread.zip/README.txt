# Whisper-to-Cards bundle

Open **notes.html** in a browser (works offline).

- **notes.pdf** is included if we could generate it.
- **audio/** has per-section audio if you created it.
- **fonts/** are embedded so the page renders offline.
